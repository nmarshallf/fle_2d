# fle_2d

If you find the code useful, please cite the corresponding paper:

Nicholas F. Marshall, Oscar Mickelin, Amit Singer. Fast expansion into harmonics on the disk: a steerable basis with fast radial convolutions. arXiv (2022). 
https://arxiv.org/abs/2207.13674
